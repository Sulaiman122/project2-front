import React from 'react'

const Game4 = () => {
    return (
        <div>
            
        </div>
    )
}

export default Game4
