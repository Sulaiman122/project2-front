import React, { useEffect, useRef, useState } from "react";
import "./style.css";
const Game3 = () => {
  var numSquares = 6;
  var colors;
  var pickedColor;

  useEffect(() => {
    setcolorDisplay(pickedColor);
    colors = generateRandomColors(numSquares);
    pickedColor = pickColor(numSquares);
  }, []);
  var squares = document.querySelectorAll(".square");
  //   var colorDisplay = document.getElementById("colorDisplay");
  //   var messageDisplay = document.querySelector("#message");
  const [colorDisplay, setcolorDisplay] = useState("RGB");
  const [messageDisplay, setmessageDisplay] = useState("");
  const [resetmessage, setresetmessage] = useState("New Colors");
  const [sqrnumber, setnumSquares] = useState(6);
  const [level, setlevel] = useState("hard");

  var h1 = document.querySelector("h1");
  //   var resetButton = document.querySelector("#reset");
  var EsyBTN = document.querySelector("#easyBtn");
  var HrdBTN = document.querySelector("#hardBtn");

  const easyBtn = () => {
    EsyBTN.classList.add("selected");
    HrdBTN.classList.remove("selected");
    // //stop it from clicking again
    EsyBTN.disabled = true;
    HrdBTN.disabled = false;
    //generate 3 new colors
    numSquares = 3;
    setnumSquares(3);
    setlevel("easy");
    colors = generateRandomColors(numSquares);
    console.log("what colors do i have ", colors);
    //pick a new random color from array
    pickedColor = pickColor(numSquares);
    console.log("picked color ", pickedColor);
    //change MessageDisplay to the new color
    // colorDisplay.textContent = pickedColor;
    setcolorDisplay(pickedColor);
    //remove backgroundColor from header
    h1.style.backgroundColor = "steelblue";
    //give the new squares backgrounds
    for (var i = 0; i < 3; i++) {
      //do these things if the from the 3 because we generate 3
      if (colors[i]) {
        squares[i].style.backgroundColor = colors[i];
      } else {
        squares[i].style.display = "none";
      }
    }
    console.log("ايزي بتن");
    printSquares();
  };

  const hardBtn = () => {
    HrdBTN.classList.add("selected");
    EsyBTN.classList.remove("selected");
    // //stop it from clicking again
    EsyBTN.disabled = false;
    HrdBTN.disabled = true;
    //generate new colors
    numSquares = 6;
    setnumSquares(6);
    setlevel("hard");
    colors = generateRandomColors(numSquares);
    //pick a new random color from array
    pickedColor = pickColor(numSquares);
    console.log('this is ittttttttttttt ',pickedColor);
    //change MessageDisplay to the new color
    // colorDisplay.textContent = pickedColor;
    setcolorDisplay(pickedColor);
    //remove backgroundColor from header
    h1.style.backgroundColor = "steelblue";
    //give the new squares backgrounds
    for (var i = 0; i < 6; i++) {
      //do these things if the from the 3 because we generate 3
      squares[i].style.backgroundColor = colors[i];
      squares[i].style.display = "block";
    }
    console.log("هارد بتن");
    printSquares();
  };

  const resetButton = () => {
    //generate all new colors
    // colors = generateRandomColors(sqrnumber);
    // console.log(sqrnumber);
    // console.log('colors ',colors);
    //pick a new random color from array
    // pickedColor = pickColor(sqrnumber);
    // console.log('reset picked color ',pickedColor);
    //change MessageDisplay to the new color
    // colorDisplay.textContent = pickedColor;
    // setcolorDisplay(pickedColor)
    //remove "correct/try again"
    // messageDisplay.textContent = "";
    setmessageDisplay("");
    //after win the button text goes to "play again" and doesn't return back
    // resetButton.textContent = "New Colors";
    pickedColor=""
    setresetmessage("New Colors");
    console.log(level);
    if (level == "hard") {
      hardBtn();
    } else if (level == "easy") {
      easyBtn();
    }
    // //change colors of squares
    // for (var i = 0; i < squares.length; i++) {
    //   //add new colors to squares
    //   squares[i].style.backgroundColor = colors[i];
    // }
    // //remove backgroundColor from header
    // h1.style.backgroundColor = "steelblue";
    // printSquares();
  };

  const printSquares = () => {
    console.log("squares in print ", squares);
    for (var i = 0; i < squares.length; i++) {
      //add initial colors to squares
      squares[i].style.backgroundColor = colors[i];
      //add click listeners to squares
      squares[i].addEventListener("click", function () {
        //grap color of clicked square
        var clickedColor = this.style.backgroundColor;
        console.log("clicked color ", clickedColor);
        console.log("picked color ", pickedColor);
        //compare color to pickedColor

        if (clickedColor === pickedColor) {
          // messageDisplay.textContent = "Correct!!";
          setmessageDisplay("Correct!!");
          changeColor(clickedColor);
          h1.style.backgroundColor = clickedColor;
          // resetButton.textContent = "Play Again?";
          setresetmessage("Play Again");
        } else {
          this.style.backgroundColor = "#232323";
          this.style.cursor = "default";
          // messageDisplay.textContent = "Try Again";
          setmessageDisplay("Try Again");
        }
      });
    }
  };

  function changeColor(color) {
    //loop through all squares
    for (var i = 0; i < squares.length; i++) {
      //change each color to match given color
      squares[i].style.backgroundColor = color;
    }
  }

  function pickColor(numSquares) {
    var random = Math.floor(Math.random() * numSquares);
    return colors[random];
  }

  function generateRandomColors(num) {
    console.log("accessed generateRandom");
    //make an array
    var arr = [];
    //repeat num times
    for (var i = 0; i < num; i++) {
      //get random color and push into arr
      arr[i] = randomColor();
    }
    //return that array
    return arr;
  }

  function randomColor() {
    var r = Math.floor(Math.random() * 256);
    var g = Math.floor(Math.random() * 256);
    var b = Math.floor(Math.random() * 256);
    return "rgb(" + r + ", " + g + ", " + b + ")";
  }

  return (
    <div className="game3">
      <h1>
        The Great<span id="colorDisplay">{colorDisplay}</span>Color Game
      </h1>
      <div id="stripe">
        <button id="reset" onClick={resetButton}>
          {resetmessage}
        </button>
        <span id="message">{messageDisplay}</span>
        <button id="easyBtn" onClick={easyBtn}>
          Easy
        </button>
        <button id="hardBtn" class="selected" onClick={hardBtn}>
          Hard
        </button>
      </div>

      <div class="container">
        <div class="square"></div>
        <div class="square"></div>
        <div class="square"></div>
        <div class="square"></div>
        <div class="square"></div>
        <div class="square"></div>
      </div>
    </div>
  );
};

export default Game3;
