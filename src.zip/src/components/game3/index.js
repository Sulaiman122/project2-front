import React from 'react'

const Game3 = () => {
    return (
        <div>
            
        </div>
    )
}

export default Game3
