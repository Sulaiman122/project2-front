import React, { useState, useEffect, useRef } from "react";
import "./style.css";
import { Link } from "react-router-dom";

const Game2 = () => {
  const [clicked, setClicked] = useState([
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
  ]);
  const board = useRef(null);
  let turn;
  const [resultMessage, setResultMessage] = useState("");
  const [show, setShow] = useState("");
  const winLines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  let imagination = ["", "", "", "", "", "", "", "", ""];
  const ComputerPlay=()=>{
    const divs = board.current.childNodes;
    
    let available;

    for(let i=0;i<divs.length;i++){
      // if(divs[i].classList[1].includes('x')){
        console.log('hiiiii',divs[i]?.classList[1].includes('x'));
      // }
    }
    let random = divs[Math.floor(Math.random()*divs.length)];
    if(divs[0].classList[0].includes('cell')){
    console.log(available);
    }
  }

  const handleClick = (e, cellNo) => {
    if (clicked[cellNo]) {
      clicked[cellNo] = false;
      console.log("clicked ", board.current);
      const cell = e.target;
      let currentTurn = turn ? "o" : "x";

      imagination.splice(cellNo, 1, currentTurn);
      cell.classList.add(currentTurn);

      //swap turns
      turn = !turn;
      //we then remove hover after swap
      board.current.classList.remove("x");
      board.current.classList.remove("o");
      if (turn) {
        board.current.classList.add("o");
      } else {
        board.current.classList.add("x");
      }
      //check if win
      let isWin;
      let draw = imagination.every((item) => {
        if (item == "o" || item == "x") return true;
      });
      console.log(draw);
      if (
        winLines.some((combinations) => {
          return combinations.every((index) => {
            return imagination[index].includes(currentTurn);
          });
        })
      ) {
        // let draw = false;

        if (currentTurn == "o") {
          setResultMessage("You Win!");
          setShow("show");
        } else if (currentTurn == "x") {
          setResultMessage("Computer Win");
          setShow("show");
        }
      } else if (draw) {
        setResultMessage("Draw");
        setShow("show");
      }
      ComputerPlay();
    }
  };

  return (
    <div>
      <div className="board o" ref={board}>
        <div
          className="cell"
          onClick={(e) => {
            handleClick(e, 0);
          }}
        ></div>
        <div
          className="cell"
          onClick={(e) => {
            handleClick(e, 1);
          }}
        ></div>
        <div
          className="cell"
          onClick={(e) => {
            handleClick(e, 2);
          }}
        ></div>
        <div
          className="cell"
          onClick={(e) => {
            handleClick(e, 3);
          }}
        ></div>
        <div
          className="cell"
          onClick={(e) => {
            handleClick(e, 4);
          }}
        ></div>
        <div
          className="cell"
          onClick={(e) => {
            handleClick(e, 5);
          }}
        ></div>
        <div
          className="cell"
          onClick={(e) => {
            handleClick(e, 6);
          }}
        ></div>
        <div
          className="cell"
          onClick={(e) => {
            handleClick(e, 7);
          }}
        ></div>
        <div
          className="cell"
          onClick={(e) => {
            handleClick(e, 8);
          }}
        ></div>
      </div>
      <div className={`result ${show}`}>
        <div className="text">{resultMessage}</div>
        <button>Restart</button>
      </div>
      <Link to="/">
        <button>go home</button>
      </Link>
    </div>
  );
};

export default Game2;
